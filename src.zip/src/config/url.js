export const APIURL="http://localhost:3001/main/"

export const USERAPI="http://localhost:3001/users/"